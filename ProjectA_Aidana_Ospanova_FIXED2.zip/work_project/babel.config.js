// babel.config.js
// Babel configuration for Expo + React Native Reanimated
//
// IMPORTANT: 'react-native-reanimated/plugin' MUST be listed last in the
// plugins array. Reanimated requires its Babel plugin to transform worklets
// (animated functions) at compile time. Without this, Reanimated v3 will
// throw TurboModule / invariant errors at runtime on Android.

module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      // Reanimated plugin must be last
      'react-native-reanimated/plugin',
    ],
  };
};
